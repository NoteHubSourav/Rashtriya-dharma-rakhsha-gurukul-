INSTRUCTIONS:
1. Replace images in /images folder with your real ones.
2. Use the same filenames (like kalki-bg.jpg, image1.jpg, etc.).
3. Upload the project to GitHub Pages or Netlify to publish your website.
